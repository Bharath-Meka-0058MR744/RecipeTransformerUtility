package my.c10s;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.ns.Namespace;
import com.softwareag.util.IDataMap;
import com.wm.app.b2b.server.*;
import java.util.*;
import com.wm.lang.ns.*;
// --- <<IS-END-IMPORTS>> ---

public final class utils

{
	// ---( internal utility methods )---

	final static utils _instance = new utils();

	static utils _newInstance() { return new utils(); }

	static utils _cast(Object o) { return (utils)o; }

	// ---( server methods )---




	public static final void filterConnectors (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(filterConnectors)>> ---
		// @sigtype java 3.5
		// [i] object:0:optional includeDisabled
		// [o] record:1:required connectors
		// [o] - field:0:required id
		// [o] - field:0:required name
		// [o] - field:0:required packageName
		// [o] - field:0:required description
		// [o] - field:0:required state
		IData[] connectors = (IData[]) ValuesEmulator.get(pipeline, "connectorList");
		
		if (connectors == null) {
			throw new ServiceException("Missing pipeline with 'connectorList'");
		}
		
		List<IData> filteredList = new LinkedList<>();
		for (IData connector: connectors) {
			IData entry = IDataFactory.create();
			IDataMap connectorMap = new IDataMap(connector);
			
			String state = connectorMap.getAsString("state", "disabled");
			if (!"enabled".equalsIgnoreCase(state)) {
				continue;
			}
			
			ValuesEmulator.put(entry, "id", connectorMap.getAsString("id"));
			ValuesEmulator.put(entry, "name", connectorMap.getAsString("name"));
			ValuesEmulator.put(entry, "description", connectorMap.getAsString("description"));
			ValuesEmulator.put(entry, "packageName", connectorMap.getAsString("packageName"));
			ValuesEmulator.put(entry, "state", state);
		
			filteredList.add(entry);
		}
		
		ValuesEmulator.remove(pipeline, "connectorList");
		ValuesEmulator.put(pipeline, "connectors", filteredList.toArray(new IData[0]));
		// --- <<IS-END>> ---

                
	}



	public static final void filterSvc (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(filterSvc)>> ---
		// @sigtype java 3.5
		// [i] field:0:required packageName
		// [i] field:0:optional connectorId
		// [o] record:1:required operations
		// [o] - field:0:required id
		// [o] - field:0:required name
		// [o] - field:0:required description
		// [o] - field:0:required type
		// [o] - field:0:required class
		// [o] record:0:required error
		// [o] - field:0:required message
		String packageName = ValuesEmulator.getNonEmptyString(pipeline, "packageName");
		
		if (packageName == null) {
			ValuesEmulator.put(pipeline, "error", errorResponse("Missing required parameter 'packageName'."));
			return;
		}
		
		com.wm.app.b2b.server.Package pkg = PackageManager.getPackage(packageName + "Ext");
		if (pkg == null) {
			pkg = PackageManager.getPackage(packageName);
			if (pkg == null) {
				ValuesEmulator.put(pipeline, "error", errorResponse("No such provider (or extension): " + packageName));
				return;
			}
		}
		
		// get all service-nodes, from the specified package
		Vector<NSService> list = Namespace.current().getServiceNodes(pkg);
		
		String connectorId = ValuesEmulator.getString(pipeline, "connectorId");
		
		List<IData> svcList = new LinkedList<>();
		Iterator<NSService> ite = list.listIterator();
		while (ite.hasNext()) {
			NSService node = ite.next();
			String id = node.toString();
			String clazzname = node.getClass().getSimpleName();
			String type = typeActionOrTrigger(id);
			
			if (type == null || !id.startsWith("fld_common.")|| !(clazzname.startsWith("Cloudstream"))) continue;
			if (connectorId != null) {
				String filterPart = connectorId.replaceAll("\\.", "_");
				if (!id.contains(filterPart)) continue; 
			}
		
			IData entry = IDataFactory.create();
			ValuesEmulator.put(entry, "id", node.toString());
			ValuesEmulator.put(entry, "name", node.getNSName().getNodeName().toString());
			ValuesEmulator.put(entry, "description", node.getComment());
		
			ValuesEmulator.put(entry, "type", type);
			//ValuesEmulator.put(entry, "class", clazzname);
		//			ValuesEmulator.put(entry, "displayName", node.getDisplayName());
		//			ValuesEmulator.put(entry, "label", node.getLabel());
		
			
			svcList.add(entry);
		}
		
		ValuesEmulator.put(pipeline, "operations", svcList.toArray(new IData[0]));
		// --- <<IS-END>> ---

                
	}

	// --- <<IS-START-SHARED>> ---
	static String typeActionOrTrigger(String id) {
		// returns action or trigger; null otherwise
		if (id.contains(".operations.actions:")) {
			return "action";
		}
		else if (id.contains(".operations.triggers:")) {
			return "trigger";
		}
		
		return null;	
	}
	
	static IData errorResponse(String message){
		IData error = IDataFactory.create();
		ValuesEmulator.put(error, "message", message);	
		
		return error;
	}
		
	// --- <<IS-END-SHARED>> ---
}

